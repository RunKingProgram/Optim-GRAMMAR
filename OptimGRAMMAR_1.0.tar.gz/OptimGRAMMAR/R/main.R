QQ_plot <- function(methodname,pValue){
    print("drawing Q-Q plot") 
    jpeg(file = paste(methodname,".QQ.Plot.jpeg",sep = ""),
         width = 600 * 5,height = 600 * 5,res = 72 * 4)
    par(mfrow = c(1,1),mar = c(3.1,3.1,0.7,1),oma = c(2.5,2.5,2.5,0),
        tcl=-0.5,mgp=c(2.8,1.3,0),lwd = 1.5)
    P.values <- as.matrix(pValue)
    N = nrow(P.values)
    P.values <- as.matrix((P.values)[order(P.values)])
    log.P.values <- as.matrix(rev(P.values)) 
    p_value_quantiles <- (1:N)/(N+1)
    log.Quantiles <- -log10(p_value_quantiles) 
    N1 = length(log.Quantiles)
    c95 <- rep(NA,N1)
    c05 <- rep(NA,N1)
    for(j in 1:N1){
        k=ceiling((10^-log.Quantiles[j])*N)
        if(k==0)k=1
        c95[j] <- qbeta(0.95,k,N-k+1)
        c05[j] <- qbeta(0.05,k,N-k+1)
    } 
    plot(NULL, xlim = c(0,max(log.Quantiles)),
         ylim = c(0,max(c(log.P.values,-log10(c05)))),
         cex.axis = 3.0, cex.lab = 2.2, type = "l",lty = 1, lwd = 5, 
         axes = TRUE, xlab = "", ylab = "",col = "gray",yaxt = "n",xaxt = "n")  
    index = length(c95):1
    polygon(c(log.Quantiles[index],log.Quantiles),c(-log10(c05)[index],-log10(c95)),
            col='gray',border = NA) 
    abline(a = 0, b = 1, col = "black",lwd=2)
    color <- c("firebrick2")
    points(log.Quantiles, log.P.values ,col=color,cex=1.1)
    x.lim <- max(log.Quantiles)
    y.lim <- max(c(log.P.values,-log10(c05)))
    axis(1,at = 1:ceiling(x.lim),cex.axis=2.3,
         labels = c(1:ceiling(max(x.lim))),tick=TRUE,lwd.ticks=3)
    axis(2,at = seq(1,ceiling(y.lim),3),cex.axis=2.3,
         labels = seq(1,ceiling(y.lim),3),tick=TRUE,lwd.ticks=3)
    box()
    palette("default") 
    mtext(expression(Observed~~-log[10](italic(p))),side=2,cex=1.9,outer=TRUE,line=-0.4)
    mtext(expression(Expected~~-log[10](italic(p))),side=1,cex=1.9,outer=TRUE)
    dev.off()
}
Manh_plot <- function(methodname,manh){
    print("drawing manhattan plot") 
    jpeg(file = paste(methodname,".Manhattan.Plot.Genomewise.jpeg",sep = ""),
         width=900*5,height=500*5,res=72*4)
    par(mfrow=c(1,1),mar=c(3.1,3.1,0.7,1),oma=c(2.5,2.5,2.5,0),
        tcl=-0.5,mgp=c(2.8,1.3,0),lwd = 1.5)
    manh0 <- manh
    cutOff <- 0.05
    manh <- matrix(as.numeric(as.matrix(manh0)),nrow(manh0),ncol(manh0)) 
    manh <- manh[manh[,1]!=0,]
    numMarker <- nrow(manh)
    bonferroniCutOff <- -log10(cutOff/numMarker)
    y.lim <- ceiling(max(manh[,3]))
    chmtoanalyze <- unique(manh[,1])
    nchr <- length(chmtoanalyze)
    chrcolor <- c("forestgreen","firebrick2","royalblue2","orangered1",
                  "gold2","violetred2","black")
    plotcolor <- rep(chrcolor,ceiling(nchr/5))
    mypch=20 
    manh <- manh[order(manh[,2]),]
    manh <- manh[order(manh[,1]),]
    ticks=NULL
    lastbase=0
    for (i in chmtoanalyze){
        index=(manh[,1]==i)
        ticks <- c(ticks, lastbase+mean(manh[index,2]))
        manh[index,2]=manh[index,2]+lastbase
        lastbase=max(manh[index,2])
    }
    x <- as.numeric(manh[,2])
    y <- as.numeric(manh[,3])
    z <- as.numeric(manh[,1])
    size = 1;ratio = 10;base = 1 
    themax = ceiling(max(y))
    themin = floor(min(y))
    wd = ((y - themin + base) / (themax - themin + base)) * size * ratio
    s = size - wd / ratio / 2
    plot(y ~ x,xlab = "",ylab = "" ,ylim = c(0,y.lim),cex.axis = 2.1, cex.lab = 2.2,col = plotcolor[z],
         axes = FALSE,type = "p",pch = mypch,lwd = wd,cex = s+.5,main = "",cex.main = 2)
    abline(h = bonferroniCutOff,col = "forestgreen")
    axis(1, at = ticks,cex.axis=2.3,labels = chmtoanalyze,tick = TRUE,lwd.ticks = 3)
    axis(2, at = seq(1,floor(y.lim),3),cex.axis = 2.3,
         labels = seq(1,floor(y.lim),3),tick = TRUE,lwd.ticks = 3) 
    box()
    palette("default")
    mtext(expression(Observed~~-log[10](italic(p))),side = 2,cex = 1.9,outer = TRUE,line = -0.4)
    mtext(expression(Chromosome),side = 1,cex = 1.9,outer = TRUE)
    dev.off()
}
Data <- function(filename, nsmar = 5000, msampling = T　){
    bed.filename <- paste(filename, ".bed", sep = "")
    fam.filename <- paste(filename, ".fam", sep = "")
    bim.filename <- paste(filename, ".bim", sep = "")
    y <- as.numeric(read.table(fam.filename)[, 6])
    nobs <- length(y)
    if (nobs > 10000) msampling = T
    if (!msampling){
        system(paste("./plink2 --bfile ", filename, 
                     " --make-rel cov square --maf --out Kingship", sep = ""))
        maf = as.numeric(read.table(paste("Kingship", ".afreq", sep = ""))[, 5])
        maf2 = NULL
    }else{
        if(nobs <= nsmar){
            system(paste("./plink2 --bfile ", filename, " --thin-count ", nsmar
                         , " --make-rel cov square --maf --out Kingship", sep = ""))
            maf = NULL
            maf2 = NULL
        }else{
            system(paste("./plink2 --bfile ", filename, " --thin-count ", nsmar
                         , " --freq --make-bed  --out t",
                         filename , sep = ""))
            tbed.filename <- paste("t", bed.filename, sep = "")
            tfam.filename <- paste("t", fam.filename, sep = "")
            tbim.filename <- paste("t", bim.filename, sep = "")
            sX<-BEDMatrix(tbed.filename)
            maf <- as.numeric(read.table(paste("t", filename, ".afreq", sep = ""))[, 5])
            transG(tbed.filename) 
            tfamfile <- fread(fam.filename, nrows = nsmar)
            fwrite(tfamfile, tfam.filename, col.names = F, 
                   row.names = F, sep = " ", quote = F)
            tfamfile <- fread(bim.filename, nrows = nobs)
            fwrite(tfamfile, tbim.filename, col.names = F,
                   row.names = F, sep = " ", quote = F)
            system(paste("./plink2 --bfile t", filename, 
                         " --allow-no-sex --make-rel cov square --freq --out Kingship", sep = ""))
            maf2 <- as.numeric(read.table(paste("Kingship.afreq", sep = ""))[, 5]) 
        }
    }
    return(list(filename = filename, msampling = msampling, nsmar = nsmar, 
                nobs = nobs, y = y, maf = maf, maf2 = maf2))
}

Grammar <- function(data_Grammar, h2, Scan = "Plink2"){
    if (data_Grammar$nobs <= data_Grammar$nsmar | !data_Grammar$msampling){
        resi <- data_Grammar$y - gblup(data_Grammar$y, h2) 
    }else{
        resi <- data_Grammar$y - 
            ridge(paste("t", data_Grammar$filename, ".bed", sep = ""),
                  data_Grammar$y, data_Grammar$maf, 
                  data_Grammar$maf2, data_Grammar$nsmar, h2)
    }
    famfile <- fread(paste(data_Grammar$filename, ".fam", sep = ""))
    write.table(resi,"resi",row.names=F,col.names=F, sep = " ", quote = F)
    if(Scan=="Plink2"){  
        famfile[,6] <- resi
        fwrite(famfile,paste(data_Grammar$filename, ".fam", sep = ""), col.names = F,
               sep = " ", quote = F)
        system(paste("./plink2 --bfile ", data_Grammar$filename, 
                     " --linear allow-no-covars --out Grammar" , sep = ""))
        result <- fread("Grammar.PHENO1.glm.linear")
        famfile[,6] <- data_Grammar$y
        fwrite(famfile,paste(data_Grammar$filename, ".fam", sep=""),
               col.names=F, sep = " ", quote = F)
        
    }else{
        fwrite(cbind(famfile[,1:2],resi), "pheno", col.names = F,sep = " ", quote = F)
        system(paste("./gcta64 --bfile ", data_Grammar$filename, 
                     " --fastGWA-lr --pheno pheno --out Grammar", sep = ""))
        result <- fread("Grammar.fastGWA", head = T)
        beta <- as.numeric(as.matrix(result[,8]))
        se <- as.numeric(as.matrix(result[,9]))
        result <- cbind(result,beta/se)  
    }
    chi <- as.numeric(as.matrix(result[,11]))^2
    gcv <- mean(chi)-0.05
    lgcv <- abs(log(gcv))
    return(lgcv)
}

optimGRAMMAR <- function(data_Grammar, maxh2=0.5, opsm = 50000,jointthrd=0.0001,Test = c("Separate","Joint") , Scan = c("Plink2","gcta"),QQ = T, Manh = T ){
    system(paste("./plink2 --bfile maize300000new --thin-count ",opsm,"  --make-bed --out tempfile"))
    ogfilename=data_Grammar$filename
    data_Grammar$filename="tempfile"
    ipmin <- optimize(Grammar,c(0,maxh2), tol = 0.05, data_Grammar = data_Grammar,Scan = Scan[1])
    optimh2 <- ipmin$minimum
    print("optimh2:")
    print(optimh2)
    data_Grammar$filename = ogfilename
    Grammar(data_Grammar,optimh2,Scan = Scan[1])
    Scan = Scan[1]
    if(Scan=="Plink2"){
        result <- fread("Grammar.PHENO1.glm.linear")
        pval <- as.numeric(as.matrix(result[,12]))
        gcv <- qchisq(na.omit(pval),1,lower.tail = F)
    }else{
        result <- fread("Grammar.fastGWA", head = T)
        pval <- as.numeric(as.matrix(result[,10]))
        gcv <- qchisq(na.omit(pval),1,lower.tail = F)
    }
    nmar <- nrow(result)
    position <- which(pval < 0.05/nmar)
    fwrite(cbind(result[position,1:9], pval[position]), "QTNs", sep=" ", quote=F)
    logp <- -log10(pval)
    if(QQ) QQ_plot( "optimGrammar", logp)
    if(Manh)  Manh_plot("optimGrammar", cbind(result[,1:2],logp))
    Test = Test[1]
    if (Test == "Jiont"){
        y <- Grammar$resi
        maxmar = length(y)
        if (maxmar > 400) maxmar = 400
        index = which( pval < 0.01)
        p0 = pval[index]
        index <- Cposi_Choice(cbind(index,p0),nmar/maxmar)[,1]
        thrd = qchisq(jointthrd,1,lower.tail=FALSE)
        jointany=fast_jiont(as.matrix(y),gcv
                            ,as.matrix(index),thrd,paste(Grammar$filename,".bed",sep=""))
        pv=pchisq(jointany$chi[-1],1,lower.tail=FALSE)
        position=which(pv < 0.05 / nmar)
        pval[jointany$position[position]]<-pv[position]
        position <- which(pval < 0.05 / nmar)
        logp <- -log10(pval)
        fwrite(cbind(Grammar$result[position,1:2], logp[position]), 
               "jointoptimGrammar_QTNs", sep = " ", quote = F)
        if(QQ) QQ_plot("jointoptimGrammar", logp)
        if(Manh) Manh_plot("jointoptimGrammar", cbind(Grammar$result[, 1:2], logp))
    }
    return(optimh2)
}