// [[Rcpp::depends(Rcpp)]]
#include <Rcpp.h>
#include <fstream>

//char const* filename
using namespace std;

// [[Rcpp::export]]
void transG(SEXP bed_in) {
  string file_bed = Rcpp::as<string>(bed_in);
  fstream infile(file_bed.c_str(), ios::in|ios::out|ios::binary);
  if (!infile) {
     cout << "NO bed file！！" << file_bed << endl;
     return;
  }
  cout<<"open success"<<endl;
   char ch[1]={ 0 };
   infile.seekg(2);
   infile.write(ch, 1);
  return;
}

