
// [[Rcpp::depends(RcppEigen)]]
#include <fstream>

#include <RcppEigen.h>

#include <cstring>
#include <cstdio>


using namespace std;
Eigen::VectorXd scaleVec(Eigen::VectorXd x){
  int nobs = x.size();
  float mean = x.sum()/nobs;
  float sd = x.array().square().sum()/nobs-mean*mean;
  x = (x.array()-mean)/sqrt(sd);
  return x;
}

// [[Rcpp::export]]
Eigen::MatrixXd ridge(SEXP bedfile_in,Eigen::VectorXd y,Eigen::VectorXd maft,Eigen::VectorXd maf2,int nmar,const float h2) {
  string bedfile = Rcpp::as<string>(bedfile_in);
  int nobs =y.size();
  ifstream readbedfile (bedfile.c_str(), ios::binary);
  if (!readbedfile) {
         cout << "NO bed file！！" << bedfile << endl;
         Eigen::VectorXd nores(1);
         nores(0)=0;
         return nores;
       }
  cout << "load bed file :" << bedfile << endl;
  int nblocks = (nobs + 3) / 4, pos;
  unsigned char magic[3], temp[2], buffer[nblocks];
  readbedfile.read((char *)magic, 3);
  Eigen::MatrixXd X(nmar+1,nmar+1);
  Eigen::VectorXd Y(nmar+1);
  Eigen::MatrixXd Cormatrix(nmar,nmar); 
  Cormatrix.setOnes(nmar,nmar);
  Eigen::VectorXd ebv(nobs);
  ebv.setZero(nobs);
  Eigen::VectorXd tempv(nmar); 
  Eigen::VectorXd Gtemp(nobs);
  Eigen::VectorXd cc(nmar);
  Eigen::VectorXd meanwrong(nobs);
  Eigen::VectorXd meanright(nmar);
  Eigen::VectorXd sdright(nmar);
  Eigen::VectorXd coef(nmar);
  X.setOnes(nmar+1,nmar+1);
  float geno;
  meanwrong=maf2.array()*2;
  meanright=maft.array()*2;
  float summeamwrong=meanwrong.array().square().sum();
  sdright=meanright.array()*(1-maft.array());
  sdright=sdright.array().sqrt();
  sdright=1/sdright.array();
  FILE *fp;
  fp=fopen("Kingship.rel","r");
  if(fp==NULL){
    printf("No Kingship.rel file!");
    return ebv.setZero(nmar);
  }   
  cout << "load tkinship file" << endl;
  char* line = NULL;
  size_t len = 0;
  for(int count=0;count<nmar;count++) { 
      getline(&line, &len, fp);
      char *ptr=NULL;
      ptr = strtok(line, "\t");
      for(int i=0;i<nmar;i++) {
         tempv(i)=atof(ptr);
         ptr = strtok(NULL, "\t");
      }
      readbedfile.seekg(count*nblocks+3);
      readbedfile.read((char *)buffer, nblocks);
      int ncount = 0;
        for(int j=0; j<nblocks; ++j) {
              pos = 0;
          for(size_t k=0; k<4; ++k) {
              if(ncount == nobs && j == nblocks - 1) {break;}
              for(size_t l=0; l<2; ++l) {
                    temp[l] = (buffer[j] >> pos) & 1;
                pos++;
              }
              if(temp[0] ==0 && temp[1] ==0){
                    geno = 2;
              } else if(temp[0] ==1 && temp[1] ==1){
                    geno = 0;
              } else {
                    geno = 1;
              }
              Gtemp(ncount)=geno;
              ncount++;
        }
      }
      X.row(count)=tempv.array()*nobs;
      Cormatrix.col(count)=Cormatrix.col(count).array()*((Gtemp.array()*meanwrong.array()).sum())-summeamwrong;
      cc(count)=meanwrong.dot(Gtemp);
      Gtemp=(Gtemp.array()-meanright(count))*sdright(count);
      X(count,nmar)=Gtemp.sum();
      X(nmar,count)=Gtemp.sum();  
      Y(count)=Gtemp.dot(y);
    } 
    X.block(0,0,nmar,nmar)=X.block(0,0,nmar,nmar)+Cormatrix;
  for (int i=0;i<nmar;i++){
    X.block(0,i,nmar,1)=X.block(0,i,nmar,1)+cc;
  }
  X.block(0,0,nmar,nmar)=(X.block(0,0,nmar,nmar).array()-(meanright*meanright.transpose()).array()).array()
    *(sdright*sdright.transpose()).array();
  Gtemp=Gtemp.setOnes(nobs).array()*nmar*(1-h2)/h2;
  X.block(0,0,nmar,nmar).diagonal()=X.block(0,0,nmar,nmar).diagonal()+Gtemp;
  Y(nmar)=y.sum();
  X(nmar,nmar)=nobs;
  coef=X.lu().solve(Y);
  for(int count=0;count<nmar;count++) { 
    readbedfile.seekg(count*nblocks+3);
    readbedfile.read((char *)buffer, nblocks);
    int ncount = 0;
    for(int j=0; j<nblocks; ++j) {
      pos = 0;
      for(size_t k=0; k<4; ++k) {
        if(ncount == nobs && j == nblocks - 1) {break;}
        for(size_t l=0; l<2; ++l) {
          temp[l] = (buffer[j] >> pos) & 1;
          pos++;
        }
        if(temp[0] ==0 && temp[1] ==0){
          geno = 2;
        } else if(temp[0] ==1 && temp[1] ==1){
          geno = 0;
        } else {
          geno = 1;
        }
        Gtemp(ncount)=geno;
        ncount++;
      }
    }
    Gtemp=(Gtemp.array()-meanright(count))*sdright(count);
    ebv=ebv.array()+coef(count)*Gtemp.array();
  }
    return ebv;
}

// [[Rcpp::export]]
Eigen::VectorXd ridge_ebv_noI(SEXP bedfile_in,Eigen::VectorXd y,Eigen::VectorXd maf,int nmar,const float h2) {
  string bedfile = Rcpp::as<string>(bedfile_in);
  int nobs =y.size();
  
  ifstream readbedfile (bedfile.c_str(), ios::binary);
  if (!readbedfile) {
    cout << "NO bed file！！" << bedfile << endl;
    Eigen::VectorXd nores(1);
    nores(0)=0;
    return nores;
  }
  cout << "load bed file :" << bedfile << endl;
  int nblocks = (nobs + 3) / 4, pos;
  unsigned char magic[3], temp[2], buffer[nblocks];
  readbedfile.read((char *)magic, 3);
  Eigen::MatrixXd X(nmar,nmar);
  Eigen::VectorXd Y(nmar);
  Eigen::VectorXd Vv(nmar);
  Eigen::VectorXd ebv(nobs);
  Eigen::VectorXd coef(nobs);
  Eigen::VectorXd tempv(nmar); 
  Eigen::VectorXd Gtemp(nobs);
  Eigen::MatrixXd bigX(nobs,nmar);
  X.setOnes(nmar+1,nmar+1);
  float geno,mean,sd;
  //mean=y.sum()/nobs;
  //y=y.array()-mean;
  FILE *fp;
  fp=fopen("Kingship.rel","r");
  if(fp==NULL){
    printf("No Kingship.rel file!");
    return ebv.setZero(nmar);
  }   
  cout << "load tkinship file" << endl;
  char* line = NULL;
  size_t len = 0;
  for(int count=0;count<nmar;count++) { 
    getline(&line, &len, fp);
    char *ptr=NULL;
    ptr = strtok(line, "\t");
    for(int i=0;i<nmar;i++) {
      tempv(i)=atof(ptr);
      ptr = strtok(NULL, "\t");
    }
    readbedfile.seekg(count*nblocks+3);
    readbedfile.read((char *)buffer, nblocks);
    int ncount = 0;
    for(int j=0; j<nblocks; ++j) {
      pos = 0;
      for(size_t k=0; k<4; ++k) {
        if(ncount == nobs && j == nblocks - 1) {break;}
        for(size_t l=0; l<2; ++l) {
          temp[l] = (buffer[j] >> pos) & 1;
          pos++;
        }
        if(temp[0] ==0 && temp[1] ==0){
          geno = 2;
        } else if(temp[0] ==1 && temp[1] ==1){
          geno = 0;
        } else {
          geno = 1;
        }
        Gtemp(ncount)=geno;
        ncount++;
      }
    }
    
    Gtemp=scaleVec(Gtemp);
    bigX.col(count)=Gtemp.array();
    Y(count)=y.dot(bigX.col(count));
    X.row(count)=tempv.array()*nmar;
  }  
  Gtemp=Gtemp.setOnes(nobs).array()*nmar*(1-h2)/h2;
  X.diagonal()=X.diagonal()+Gtemp;
  coef=X.lu().solve(Y);
  for(int count=0;count<nmar;count++) { 
    readbedfile.seekg(count*nblocks+3);
    readbedfile.read((char *)buffer, nblocks);
    int ncount = 0;
    for(int j=0; j<nblocks; ++j) {
      pos = 0;
      for(size_t k=0; k<4; ++k)  {
        if(ncount == nobs && j == nblocks - 1) {break;}
        for(size_t l=0; l<2; ++l) {
          temp[l] = (buffer[j] >> pos) & 1;
          pos++;
        }
        if(temp[0] ==0 && temp[1] ==0){
          geno = 2;
        } else if(temp[0] ==1 && temp[1] ==1){
          geno = 0;
        } else {
          geno = 1;
        }
        Gtemp(ncount)=geno;
        ncount++;
      }
    }
    ebv = ebv.array()+Gtemp.array()*coef(count);
  }
  return ebv;
}




// [[Rcpp::export]]
Eigen::VectorXd ridge_ebv_tXX(SEXP bedfile_in,Eigen::VectorXd y,int nmar,const float h2) {
  string bedfile = Rcpp::as<string>(bedfile_in);
  int nobs =y.size();
  ifstream readbedfile (bedfile.c_str(), ios::binary);
  if (!readbedfile) {
    cout << "NO bed file！！" << bedfile << endl;
    Eigen::VectorXd nores(1);
    nores(0)=0;
    return nores;
  }
  cout << "load bed file :" << bedfile << endl;
  int nblocks = (nobs + 3) / 4, pos;
  unsigned char magic[3], temp[2], buffer[nblocks];
  readbedfile.read((char *)magic, 3);
  Eigen::MatrixXd X(nmar+1,nmar+1);
  Eigen::VectorXd Y(nmar+1);
  Eigen::VectorXd ebv(nobs);
  Eigen::VectorXd coef(nobs+1);
  Eigen::VectorXd tempv(nmar); 
  Eigen::VectorXd Gtemp(nobs);
  //Eigen::MatrixXd bigX(nobs,nmar);
  X.setOnes(nmar+1,nmar+1);
  float geno,mean,sd;
  FILE *fp;
  fp=fopen("Kingship.rel","r");
  if(fp==NULL){
    printf("No Kingship.rel file!");
    return ebv.setZero(nmar);
  }   
  cout << "load tkinship file" << endl;
  char* line = NULL;
  size_t len = 0;
  for(int count=0;count<nmar;count++) { 
    getline(&line, &len, fp);
    
    char *ptr=NULL;
    ptr = strtok(line, "\t");
    for(int i=0;i<nmar;i++) {
      tempv(i)=atof(ptr);
      ptr = strtok(NULL, "\t");
    }
    readbedfile.seekg(count*nblocks+3);
    readbedfile.read((char *)buffer, nblocks);
    int ncount = 0;
    for(int j=0; j<nblocks; ++j) {
      pos = 0;
      for(size_t k=0; k<4; ++k) {
        if(ncount == nobs && j == nblocks - 1) {break;}
        for(size_t l=0; l<2; ++l) {
          temp[l] = (buffer[j] >> pos) & 1;
          pos++;
        }
        if(temp[0] ==0 && temp[1] ==0){
          geno = 2;
        } else if(temp[0] ==1 && temp[1] ==1){
          geno = 0;
        } else {
          geno = 1;
        }
        Gtemp(ncount)=geno;
        ncount++;
      }
    }
    mean = Gtemp.sum()/nobs;
    Gtemp=Gtemp.array()-mean;
    //Gtemp = scaleVec(Gtemp);
    // bigX.col(count)=Gtemp;
    X.row(count)=tempv.array()*nmar;
    X(count,nmar)=Gtemp.sum();
    Y(count)=y.dot(Gtemp);
    X(count,count)=X(count,count)+nmar*(1-h2)/h2;
  } 
  //free(line);
  Y(nmar)=y.sum();
  X(nmar,nmar)=nmar;
  coef=X.lu().solve(Y);
  //ebv=bigX*ebv;
  for(int count=0;count<nmar;count++) { 
    readbedfile.seekg(count*nblocks+3);
    readbedfile.read((char *)buffer, nblocks);
    int ncount = 0;
    for(int j=0; j<nblocks; ++j) {
      pos = 0;
      for(size_t k=0; k<4; ++k)  {
        if(ncount == nobs && j == nblocks - 1) {break;}
        for(size_t l=0; l<2; ++l) {
          temp[l] = (buffer[j] >> pos) & 1;
          pos++;
        }
        if(temp[0] ==0 && temp[1] ==0){
          geno = 2;
        } else if(temp[0] ==1 && temp[1] ==1){
          geno = 0;
        } else {
          geno = 1;
        }
        Gtemp(ncount)=geno;
        ncount++;
      }
    }
    ebv = ebv.array()+Gtemp.array()*coef(count);
  }
  return ebv;
}





// [[Rcpp::export]]
Eigen::VectorXd ridge_ebe_selftXX(SEXP bedfile_in,Eigen::VectorXd y,int nmar,const float h2) {
  
  string bedfile = Rcpp::as<string>(bedfile_in);
  int nobs =y.size();
  ifstream readbedfile (bedfile.c_str(), ios::binary);
  if (!readbedfile) {
    cout << "NO bed file！！" << bedfile << endl;
    Eigen::VectorXd nores(1);
    nores(0)=0;
    return nores;
  }
  cout << "load bed file :" << bedfile << endl;
  int nblocks = (nobs + 3) / 4, pos;
  unsigned char magic[3], temp[2], buffer[nblocks];
  readbedfile.read((char *)magic, 3);
  Eigen::MatrixXd X(nmar+1,nmar+1);
  Eigen::VectorXd Y(nmar+1);
  Eigen::VectorXd Vv(nmar);
  Eigen::VectorXd ebv(nobs+1);
  Eigen::VectorXd tempv(nmar); 
  Eigen::VectorXd Gtemp(nobs);
  Eigen::MatrixXd bigX(nobs,nmar);
  X.setZero(nmar+1,nmar+1);
  float geno,mean,sd;
  
  for(int count=0;count<nmar;count++) { 
    readbedfile.seekg(count*nblocks+3);
    readbedfile.read((char *)buffer, nblocks);
    int ncount = 0;
    for(int j=0; j<nblocks; ++j) {
      pos = 0;
      for(size_t k=0; k<4; ++k) {
        if(ncount == nobs && j == nblocks - 1) {break;}
        for(size_t l=0; l<2; ++l) {
          temp[l] = (buffer[j] >> pos) & 1;
          pos++;
        }
        if(temp[0] ==0 && temp[1] ==0){
          geno = 2;
        } else if(temp[0] ==1 && temp[1] ==1){
          geno = 0;
        } else {
          geno = 1;
        }
        Gtemp(ncount)=geno;
        ncount++;
      }
    }
    Gtemp = scaleVec(Gtemp);
    bigX.col(count)=Gtemp;
    X.row(count)=tempv.array();
    X(count,nmar)=Gtemp.sum();
    Y(count)=y.dot(Gtemp);
    X(count,count)=X(count,count)+nmar*(1-h2)/h2;
  } 
  X.block(0,0,nmar,nmar)=X.block(0,0,nmar,nmar)+(bigX.transpose()*bigX);
  Y(nmar)=y.sum();
  X(nmar,nmar)=nmar;
  ebv=X.lu().solve(Y);
  ebv=bigX*ebv;
  return ebv.head(nobs);
}


