// [[Rcpp::depends(RcppEigen)]]
#include <RcppEigen.h>
#include <fstream>


using namespace std;

// [[Rcpp::export]]
Eigen::VectorXd gblup(Eigen::VectorXd y, const float h2) {
  const int nobs = y.size();
  Eigen::MatrixXd X(nobs+1,nobs+1);
  Eigen::VectorXd Y(nobs+1);
  Eigen::VectorXd ebv(nobs+1);
  Eigen::VectorXd tempv(nobs); 
  X.setOnes(nobs+1,nobs+1);
  FILE *fp;
  fp=fopen("Kingship.rel","r");
  if(fp==NULL){
    printf("No Kingship.rel file!");
    return ebv.setZero(nobs);
  }   
  char* line = NULL;
  size_t len = 0;
  for(int count=0;count<nobs;count++) { 
      getline(&line, &len, fp);
      char *ptr=NULL;
      ptr = strtok(line, "\t");
      for(int i=0;i<nobs;i++) {
         tempv(i)=atof(ptr);
          ptr = strtok(NULL, "\t");
      }
      X.row(count)=tempv;
      X(count,nobs)=tempv.sum();
      Y(count)=y.dot(tempv);
      X(count,count)=X(count,count)+(1-h2)/h2;
  }
  free(line);
  Y(nobs)=y.sum();
  X(nobs,nobs)=nobs;
  ebv = X.lu().solve(Y);
  return ebv.head(nobs);
}

